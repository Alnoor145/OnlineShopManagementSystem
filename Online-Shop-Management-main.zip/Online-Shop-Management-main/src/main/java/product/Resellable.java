package product;

public interface Resellable {
    float getResalePrice();
}