package product;

public interface Warranty {
    public int getWarrantyInMonths();
}
