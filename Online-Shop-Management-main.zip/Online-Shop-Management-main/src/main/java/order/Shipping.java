package order;

public interface Shipping {
    void beginShipping();
    void cancelShipping();
    void ShipmentDelivered();
}
